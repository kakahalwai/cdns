while(x < 10;)
