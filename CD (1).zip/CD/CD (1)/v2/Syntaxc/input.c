while(x < 10);
