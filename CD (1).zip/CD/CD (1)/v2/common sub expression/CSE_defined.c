#include <stdio.h>
#include <string.h>

// Structure to represent a quadruple
typedef struct {
    char op[3];  // Operator
    char arg1[5]; // First argument
    char arg2[5]; // Second argument
    char result[5]; // Result variable
} Quadruple;

// Function to check if two quadruples have the same expression
int isSameExpression(Quadruple q1, Quadruple q2) {
    if (strcmp(q1.op, q2.op) != 0) {
        return 0;
    }

    // Check if the expression is the same, considering commutative operations
    if ((strcmp(q1.arg1, q2.arg1) == 0 && strcmp(q1.arg2, q2.arg2) == 0) ||
        ((strcmp(q1.op, "+") == 0 || strcmp(q1.op, "*") == 0) &&
        (strcmp(q1.arg1, q2.arg2) == 0 && strcmp(q1.arg2, q2.arg1) == 0))) {
        return 1;
    }

    return 0;
}

// Function to perform Common Subexpression Elimination
void eliminateCommonSubexpressions(Quadruple quads[], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (isSameExpression(quads[i], quads[j])) {
                // Replace the result of the current quadruple with the result of the earlier one
                strcpy(quads[i].op, "=");
                strcpy(quads[i].arg1, quads[j].result);
                strcpy(quads[i].arg2, "");
            }
        }
    }
}

// Function to print the quadruples
void printQuadruples(Quadruple quads[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%s = %s %s %s\n", quads[i].result, quads[i].op, quads[i].arg1, quads[i].arg2);
    }
}

int main() {
    // Predefined set of quadruples
    Quadruple quads[] = {
        {"+", "g", "f", "a"},
        {"+", "g", "a", "b"},
        {"+", "g", "a", "c"},
        {"+", "c", "a", "d"}
    };

    int n = sizeof(quads) / sizeof(quads[0]);

    printf("Before CSE:\n");
    printQuadruples(quads, n);

    eliminateCommonSubexpressions(quads, n);

    printf("\nAfter CSE:\n");
    printQuadruples(quads, n);

    return 0;
}
