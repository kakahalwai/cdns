#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Define the structure for a quadruple
typedef struct {
    char op[4];
    char arg1[10];
    char arg2[10];
    char result[10];
} Quadruple;

// Symbol table to track known constant values for temp variables
typedef struct {
    char name[10];
    int value;
    int isConstant;
} SymbolTableEntry;

int isNumber(const char *str) {
    for (int i = 0; str[i]; i++) {
        if (!isdigit(str[i]) && str[i] != '-') return 0;
    }
    return 1;
}

// Find a symbol in the symbol table
int lookup(SymbolTableEntry table[], int size, const char *name) {
    for (int i = 0; i < size; i++) {
        if (strcmp(table[i].name, name) == 0 && table[i].isConstant)
            return i;
    }
    return -1;
}

void applyConstantFolding(Quadruple quads[], int n) {
    SymbolTableEntry symtab[100];
    int symCount = 0;

    for (int i = 0; i < n; i++) {
        char arg1Val[10], arg2Val[10];
        strcpy(arg1Val, quads[i].arg1);
        strcpy(arg2Val, quads[i].arg2);

        int arg1Index = lookup(symtab, symCount, arg1Val);
        int arg2Index = lookup(symtab, symCount, arg2Val);

        // If either argument is a known constant, replace it
        if (arg1Index != -1)
            sprintf(arg1Val, "%d", symtab[arg1Index].value);
        if (arg2Index != -1)
            sprintf(arg2Val, "%d", symtab[arg2Index].value);

        // If both args are constants, fold the result
        if (isNumber(arg1Val) && isNumber(arg2Val)) {
            int val1 = atoi(arg1Val);
            int val2 = atoi(arg2Val);
            int result;
            int valid = 1;

            if (strcmp(quads[i].op, "+") == 0)
                result = val1 + val2;
            else if (strcmp(quads[i].op, "-") == 0)
                result = val1 - val2;
            else if (strcmp(quads[i].op, "*") == 0)
                result = val1 * val2;
            else if (strcmp(quads[i].op, "/") == 0 && val2 != 0)
                result = val1 / val2;
            else
                valid = 0;

            if (valid) {
                // Replace quad with folded result
                strcpy(quads[i].op, "=");
                sprintf(quads[i].arg1, "%d", result);
                strcpy(quads[i].arg2, "");

                // Store result in symbol table
                strcpy(symtab[symCount].name, quads[i].result);
                symtab[symCount].value = result;
                symtab[symCount].isConstant = 1;
                symCount++;
            }
        }
    }
}

void printQuadruples(Quadruple quads[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%s %s %s %s\n", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].result);
    }
}

int main() {
    // Example quadruples
    Quadruple quads[] = {
        {"+", "2", "3", "t1"},
        {"*", "t1", "4", "t2"},
        {"+", "t2", "5", "t3"},
        {"-", "10", "3", "t4"},
        {"*", "t3", "t4", "result"}
    };

    int n = sizeof(quads) / sizeof(Quadruple);

    printf("Before Constant Folding:\n");
    printQuadruples(quads, n);

    applyConstantFolding(quads, n);

    printf("\nAfter Constant Folding:\n");
    printQuadruples(quads, n);

    return 0;
}
