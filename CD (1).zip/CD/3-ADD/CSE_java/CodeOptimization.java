import java.util.*;

public class CodeOptimization {
    private Quadruple[] quadrapleTable;
    private int noOfStatements;
    private Map<String, int[]> constants;

    public CodeOptimization() {
        this.constants = new HashMap<>();
    }

    public void takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("No. of statements: ");
        noOfStatements = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        quadrapleTable = new Quadruple[noOfStatements];
        for (int i = 0; i < noOfStatements; i++) {
            System.out.print((i + 1) + ": ");
            String input = scanner.nextLine();
            quadrapleTable[i] = new Quadruple(input);
        }
    }

    public void optimize() {
        for (int n = 0; n < noOfStatements; n++) {
            Quadruple currentQuad = quadrapleTable[n];
            if (currentQuad.getOperator().equals("+") && currentQuad.getArg2().startsWith("z")) {
                System.out.println("\nOptimizing at state: " + (n + 1));
                currentQuad.setArg1("new value"); // Example optimization, replace with actual optimization logic
            }
        }
    }

    public void printQuadTable() {
        System.out.println("+-----+----------+------+------+--------+");
        System.out.println("| No. | Operator | Arg1 | Arg2 | Result |");
        System.out.println("+-----+----------+------+------+--------+");
        for (Quadruple quad : quadrapleTable) {
            if (quad != null) {
                System.out.println(String.format("| %-4s| %-9s| %-5s| %-5s| %-7s|",
                        quad.getNumber(),
                        quad.getOperator(),
                        quad.getArg1(),
                        quad.getArg2(),
                        quad.getResult()));
            }
        }
        System.out.println("+-----+----------+------+------+--------+");
    }

    public static void main(String[] args) {
        CodeOptimization s = new CodeOptimization();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input Table:");
        s.takeInput();
        s.printQuadTable();
        s.optimize();
        scanner.close();
    }
}

class Quadruple {
    private String number;
    private String operator;
    private String arg1;
    private String arg2;
    private String result;

    public Quadruple(String input) {
        String[] parts = input.split("\\s+", 4);
        this.number = parts[0];
        this.operator = parts[1];
        if (parts.length > 2) {
            this.arg1 = parts[2];
        } else {
            this.arg1 = "";
        }
        if (parts.length > 3) {
            this.arg2 = parts[3];
        } else {
            this.arg2 = "";
        }
        this.result = ""; // Initialize result as empty string
    }

    public String getNumber() {
        return number;
    }

    public String getOperator() {
        return operator;
    }

    public String getArg1() {
        return arg1;
    }

    public String getArg2() {
        return arg2;
    }

    public String getResult() {
        return result;
    }

    public void setArg1(String arg1) {
        this.arg1 = arg1;
    }

    public void setArg2(String arg2) {
        this.arg2 = arg2;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
