#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_INSTRUCTIONS 100
#define MAX_LENGTH 50

typedef struct {
    char op[MAX_LENGTH];
    char arg1[MAX_LENGTH];
    char arg2[MAX_LENGTH];
    char result[MAX_LENGTH];
} Instruction;

typedef struct {
    Instruction instructions[MAX_INSTRUCTIONS];
    int count;
} CodeBlock;

bool isLoopInvariant(Instruction *instr, char loopVar[MAX_LENGTH]) {
    // A simple check for loop invariance: if the instruction does not use the loop variable
    return strcmp(instr->arg1, loopVar) != 0 && strcmp(instr->arg2, loopVar) != 0;
}

void printCodeBlock(CodeBlock *block) {
    for (int i = 0; i < block->count; i++) {
        printf("%s = %s %s %s\n", block->instructions[i].result, block->instructions[i].op, block->instructions[i].arg1, block->instructions[i].arg2);
    }
}

void applyLICM(CodeBlock *block, char loopVar[MAX_LENGTH]) {
    CodeBlock preLoop, postLoop;
    preLoop.count = 0;
    postLoop.count = 0;

    bool inLoop = false;
    for (int i = 0; i < block->count; i++) {
        if (strcmp(block->instructions[i].op, "L1:") == 0) {
            inLoop = true;
        }

        if (inLoop) {
            if (isLoopInvariant(&block->instructions[i], loopVar)) {
                preLoop.instructions[preLoop.count++] = block->instructions[i];
            } else {
                postLoop.instructions[postLoop.count++] = block->instructions[i];
            }
        } else {
            preLoop.instructions[preLoop.count++] = block->instructions[i];
        }

        if (strcmp(block->instructions[i].op, "goto") == 0 && strcmp(block->instructions[i].arg1, "L1") == 0) {
            inLoop = false;
        }
    }

    // Combine preLoop and postLoop blocks
    block->count = 0;
    for (int i = 0; i < preLoop.count; i++) {
        block->instructions[block->count++] = preLoop.instructions[i];
    }
    for (int i = 0; i < postLoop.count; i++) {
        block->instructions[block->count++] = postLoop.instructions[i];
    }
}

int main() {
    // Example 3-address code block
    CodeBlock block = {
        .instructions = {
            {"", "a", "b", "t1"},
            {"", "c", "d", "t2"},
            {"L1:", "", "", ""},
            {"*", "t1", "e", "t3"},
            {"*", "t2", "f", "t4"},
            {"+", "t3", "t4", "g"},
            {"+", "e", "1", "e"},
            {"if", "e", "n", "goto L1"}
        },
        .count = 8
    };

    printf("Original Code:\n");
    printCodeBlock(&block);

    applyLICM(&block, "e");

    printf("\nOptimized Code:\n");
    printCodeBlock(&block);

    return 0;
}
