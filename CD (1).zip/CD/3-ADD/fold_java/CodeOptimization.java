import java.util.*;

class CodeOptimization {
    List<String[]> quadrapleTable = new ArrayList<>();
    int noOfStatements = 0;
    List<String> result = new ArrayList<>();
    Map<String, Integer[]> constants = new HashMap<>();

    public void takeInput() {
        Scanner scanner = new Scanner(System.in);
        List<String> state = new ArrayList<>();
        System.out.print("No. of statements: ");
        noOfStatements = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        for (int i = 0; i < noOfStatements; i++) {
            System.out.print((i + 1) + ": ");
            state.add(scanner.nextLine());
        }
        makeQudraple(state);
    }

    public void makeQudraple(List<String> inputStates) {
        noOfStatements = inputStates.size();
        for (int n = 0; n < noOfStatements; n++) {
            String[] var = inputStates.get(n).split(" ");
            if (var.length == 4) {
                quadrapleTable.add(new String[]{Integer.toString(n + 1), var[0], var[1], var[2], var[3]});
            } else if (var.length == 3) {
                quadrapleTable.add(new String[]{Integer.toString(n + 1), var[0], var[1], "  ", var[2]});
                if (var[1].matches("\\d+")) {
                    constants.put(var[2], new Integer[]{Integer.parseInt(var[1]), n});
                }
            }
        }
    }

    public void constantFoldingAndPropagation() {
        result.clear();
        result.add(quadrapleTable.get(0)[4]);
        int n = 1;
        while (true) {
            if (n >= noOfStatements) {
                return;
            }
            for (int i = n - 1; i >= 0; i--) {
                if (constants.containsKey(quadrapleTable.get(i)[2]) && i >= constants.get(quadrapleTable.get(i)[2])[1]) {
                    quadrapleTable.get(i)[2] = Integer.toString(constants.get(quadrapleTable.get(i)[2])[0]);
                }
                if (constants.containsKey(quadrapleTable.get(i)[3]) && i >= constants.get(quadrapleTable.get(i)[3])[1]) {
                    quadrapleTable.get(i)[3] = Integer.toString(constants.get(quadrapleTable.get(i)[3])[0]);
                }
                if (Arrays.asList("+", "-", "/", "*", "%").contains(quadrapleTable.get(i)[1]) &&
                        quadrapleTable.get(i)[2].matches("\\d+") && quadrapleTable.get(i)[3].matches("\\d+")) {
                    int sum;
                    switch (quadrapleTable.get(i)[1]) {
                        case "+":
                            sum = Integer.parseInt(quadrapleTable.get(i)[2]) + Integer.parseInt(quadrapleTable.get(i)[3]);
                            quadrapleTable.remove(i);
                            quadrapleTable.get(i)[2] = Integer.toString(sum);
                            constants.put(quadrapleTable.get(i)[4], new Integer[]{sum, i});
                            noOfStatements--;
                            break;
                        case "*":
                            sum = Integer.parseInt(quadrapleTable.get(i)[2]) * Integer.parseInt(quadrapleTable.get(i)[3]);
                            quadrapleTable.remove(i);
                            quadrapleTable.get(i)[2] = Integer.toString(sum);
                            constants.put(quadrapleTable.get(i)[4], new Integer[]{sum, i});
                            noOfStatements--;
                            break;
                        case "/":
                            sum = Integer.parseInt(quadrapleTable.get(i)[2]) / Integer.parseInt(quadrapleTable.get(i)[3]);
                            quadrapleTable.remove(i);
                            quadrapleTable.get(i)[2] = Integer.toString(sum);
                            constants.put(quadrapleTable.get(i)[4], new Integer[]{sum, i});
                            noOfStatements--;
                            break;
                        case "%":
                            sum = Integer.parseInt(quadrapleTable.get(i)[2]) % Integer.parseInt(quadrapleTable.get(i)[3]);
                            quadrapleTable.remove(i);
                            quadrapleTable.get(i)[2] = Integer.toString(sum);
                            constants.put(quadrapleTable.get(i)[4], new Integer[]{sum, i});
                            noOfStatements--;
                            break;
                    }
                }
                if (quadrapleTable.get(i)[2].matches("\\d+") && quadrapleTable.get(i)[1].equals("=")) {
                    constants.put(quadrapleTable.get(i)[4], new Integer[]{Integer.parseInt(quadrapleTable.get(i)[2]), i});
                    break;
                }
            }
            n++;
        }
    }

    public void printQuadTable() {
        System.out.println("+-----+----------+------+------+--------+");
        System.out.println("| No. | Operator | Arg1 | Arg2 | Result |");
        System.out.println("+-----+----------+------+------+--------+");
        for (int n = 0; n < noOfStatements; n++) {
            System.out.printf("| %-4s| %-9s| %-5s| %-5s| %-7s|%n",
                    quadrapleTable.get(n)[0], quadrapleTable.get(n)[1],
                    quadrapleTable.get(n)[2], quadrapleTable.get(n)[3],
                    quadrapleTable.get(n)[4]);
        }
        System.out.println("+-----+----------+------+------+--------+");
        System.out.println("\n\n Constants:");
        for (String key : constants.keySet()) {
            System.out.println(key + ": " + constants.get(key)[0]);
        }
    }

    public static void main(String[] args) {
        CodeOptimization s = new CodeOptimization();
        Scanner scanner = new Scanner(System.in);
        System.out.println("\t 1. Code Optimization");
        System.out.println("\t 2. Code Folding and Propagation");
        System.out.print("Enter your choice (1-2): ");
        int ch = scanner.nextInt();
        if (ch == 1) {
            s.takeInput();
            System.out.println("\nInput Table: ");
            s.printQuadTable();
            s.optimize();
        } else if (ch == 2) {
            s.takeInput();
            System.out.println("Input Table: ");
            s.printQuadTable();
            s.optimize();
            s.constantFoldingAndPropagation();
            s.printQuadTable();
        } else {
            System.out.println("Enter Valid Choice");
            System.exit(1);
        }
    }
}
