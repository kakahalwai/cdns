#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_QUADS 100

// Define the structure for a quadruple
typedef struct {
    char op[4];
    char arg1[10];
    char arg2[10];
    char result[10];
} Quadruple;

// Helper function to check if a string is a number
int isNumber(char *str) {
    for (int i = 0; i < strlen(str); i++) {
        if (!isdigit(str[i]) && str[i] != '-') {
            return 0;
        }
    }
    return 1;
}

// Helper function to perform constant folding on a single quadruple
void foldConstant(Quadruple *quad) {
    if (isNumber(quad->arg1) && isNumber(quad->arg2)) {
        int val1 = atoi(quad->arg1);
        int val2 = atoi(quad->arg2);
        int result;
        int valid = 1;

        if (strcmp(quad->op, "+") == 0) {
            result = val1 + val2;
        } else if (strcmp(quad->op, "-") == 0) {
            result = val1 - val2;
        } else if (strcmp(quad->op, "*") == 0) {
            result = val1 * val2;
        } else if (strcmp(quad->op, "/") == 0) {
            if (val2 != 0) {
                result = val1 / val2;
            } else {
                valid = 0; // Division by zero, invalid operation
            }
        } else {
            valid = 0; // Unsupported operation
        }

        if (valid) {
            // Convert the result back to a string and store it
            sprintf(quad->result, "%d", result);
            // Mark the operation as done
            strcpy(quad->op, "=");
            strcpy(quad->arg1, "");
            strcpy(quad->arg2, "");
        }
    }
}

// Function to apply constant folding on an array of quadruples
void applyConstantFolding(Quadruple quads[], int n) {
    for (int i = 0; i < n; i++) {
        foldConstant(&quads[i]);
    }
}

// Function to print the quadruples
void printQuadruples(Quadruple quads[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%s %s %s %s\n", quads[i].op, quads[i].arg1[0] ? quads[i].arg1 : "_", quads[i].arg2[0] ? quads[i].arg2 : "_", quads[i].result);
    }
}

int main() {
    Quadruple quads[MAX_QUADS];
    int n;

    // Input the number of quadruples
    printf("Enter the number of quadruples: ");
    if (scanf("%d", &n) != 1 || n <= 0 || n > MAX_QUADS) {
        printf("Invalid number of quadruples.\n");
        return 1;
    }

    // Input the quadruples
    printf("Enter the quadruples (op arg1 arg2 result):\n");
    for (int i = 0; i < n; i++) {
        if (scanf("%s %s %s %s", quads[i].op, quads[i].arg1, quads[i].arg2, quads[i].result) != 4) {
            printf("Invalid input format for quadruple %d.\n", i + 1);
            return 1;
        }
    }

    printf("\nBefore Constant Folding:\n");
    printQuadruples(quads, n);

    applyConstantFolding(quads, n);

    printf("\nAfter Constant Folding:\n");
    printQuadruples(quads, n);

    return 0;
}

// Enter the number of quadruples: 5
// Enter the quadruples (op arg1 arg2 result):
// + 2 3 t1
// * t1 4 t2
// + t2 5 t3
// - 10 3 t4
// * t3 t4 result

// Enter the number of quadruples: 3
// Enter the quadruples (op arg1 arg2 result):
// + 10 20 temp1
// - temp1 5 temp2
// * temp2 2 temp3

