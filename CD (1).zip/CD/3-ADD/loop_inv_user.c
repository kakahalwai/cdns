#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_INSTRUCTIONS 100
#define MAX_LENGTH 50

typedef struct {
    char op[MAX_LENGTH];
    char arg1[MAX_LENGTH];
    char arg2[MAX_LENGTH];
    char result[MAX_LENGTH];
} Instruction;

typedef struct {
    Instruction instructions[MAX_INSTRUCTIONS];
    int count;
} CodeBlock;

bool isLoopInvariant(Instruction *instr, char loopVar[MAX_LENGTH]) {
    // A simple check for loop invariance: if the instruction does not use the loop variable
    return strcmp(instr->arg1, loopVar) != 0 && strcmp(instr->arg2, loopVar) != 0 && strcmp(instr->result, loopVar) != 0;
}

void printCodeBlock(CodeBlock *block) {
    for (int i = 0; i < block->count; i++) {
        if (strcmp(block->instructions[i].op, "L1:") == 0 || strcmp(block->instructions[i].op, "goto") == 0) {
            printf("%s %s %s\n", block->instructions[i].op, block->instructions[i].arg1, block->instructions[i].arg2);
        } else {
            printf("%s = %s %s %s\n", block->instructions[i].result, block->instructions[i].op, block->instructions[i].arg1, block->instructions[i].arg2);
        }
    }
}

void applyLICM(CodeBlock *block, char loopVar[MAX_LENGTH]) {
    CodeBlock preLoop, postLoop;
    preLoop.count = 0;
    postLoop.count = 0;

    bool inLoop = false;
    for (int i = 0; i < block->count; i++) {
        if (strcmp(block->instructions[i].op, "L1:") == 0) {
            inLoop = true;
            postLoop.instructions[postLoop.count++] = block->instructions[i];
            continue;
        }

        if (inLoop) {
            if (isLoopInvariant(&block->instructions[i], loopVar)) {
                preLoop.instructions[preLoop.count++] = block->instructions[i];
            } else {
                postLoop.instructions[postLoop.count++] = block->instructions[i];
            }
        } else {
            preLoop.instructions[preLoop.count++] = block->instructions[i];
        }

        if (strcmp(block->instructions[i].op, "goto") == 0 && strcmp(block->instructions[i].arg1, "L1") == 0) {
            inLoop = false;
            postLoop.instructions[postLoop.count++] = block->instructions[i];
        }
    }

    // Combine preLoop and postLoop blocks
    block->count = 0;
    for (int i = 0; i < preLoop.count; i++) {
        block->instructions[block->count++] = preLoop.instructions[i];
    }
    for (int i = 0; i < postLoop.count; i++) {
        block->instructions[block->count++] = postLoop.instructions[i];
    }
}

int main() {
    CodeBlock block;
    block.count = 0;
    char loopVar[MAX_LENGTH];
    int numInstructions;

    printf("Enter the loop variable: ");
    scanf("%s", loopVar);

    printf("Enter the number of instructions: ");
    scanf("%d", &numInstructions);
    getchar(); // Consume the newline character

    printf("Enter the 3-address code instructions:\n");
    for (int i = 0; i < numInstructions; i++) {
        char line[MAX_LENGTH * 4];
        fgets(line, sizeof(line), stdin);
        
        Instruction instr;
        sscanf(line, "%s %s %s %s", instr.result, instr.op, instr.arg1, instr.arg2);
        
        // Special handling for label and goto instructions
        if (strcmp(instr.result, "L1:") == 0 || strcmp(instr.result, "goto") == 0) {
            strcpy(instr.op, instr.result);
            instr.result[0] = '\0';
            if (strcmp(instr.op, "goto") == 0) {
                sscanf(line, "%s %s", instr.op, instr.arg1);
                instr.arg2[0] = '\0';
            }
        }

        block.instructions[block.count++] = instr;
    }

    printf("\nOriginal Code:\n");
    printCodeBlock(&block);

    applyLICM(&block, loopVar);

    printf("\nOptimized Code:\n");
    printCodeBlock(&block);

    return 0;
}
