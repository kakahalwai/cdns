#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Define quadruple structure
struct Quadruple {
    char op;
    int arg1;
    int arg2;
    string result;
};

// Function to perform constant folding optimization
vector<Quadruple> constantFolding(vector<Quadruple>& quadruples) {
    vector<Quadruple> newQuadruples;

    for (auto& quad : quadruples) {
        int arg1 = quad.arg1;
        int arg2 = quad.arg2;

        if (quad.op == '+') {
            int result = arg1 + arg2;
            newQuadruples.push_back({'=', result, 0, quad.result});
        } else if (quad.op == '-') {
            int result = arg1 - arg2;
            newQuadruples.push_back({'=', result, 0, quad.result});
        } else if (quad.op == '*') {
            int result = arg1 * arg2;
            newQuadruples.push_back({'=', result, 0, quad.result});
        } else if (quad.op == '/') {
            int result = arg1 / arg2; // ⚠️ No division by zero check!
            newQuadruples.push_back({'=', result, 0, quad.result});
        } else {
            // If operator is not arithmetic, keep as is
            newQuadruples.push_back(quad);
        }
    }

    return newQuadruples;
}

// Function to print quadruples
void printQuadruples(const vector<Quadruple>& quads) {
    for (const auto& q : quads) {
        if (q.op == '=')
            cout << q.result << " = " << q.arg1 << endl;
        else
            cout << q.result << " = " << q.arg1 << " " << q.op << " " << q.arg2 << endl;
    }
}

int main() {
    // Input: List of constant expressions
    vector<Quadruple> quads = {
        {'+', 4, 5, "t1"},
        {'*', 2, 3, "t2"},
        {'-', 10, 7, "t3"},
        {'/', 20, 5, "t4"},
        {'=', 100, 0, "x"} // assignment with constant
    };

    cout << "Original Quadruples:\n";
    printQuadruples(quads);

    auto optimized = constantFolding(quads);

    cout << "\nAfter Constant Folding:\n";
    printQuadruples(optimized);

    return 0;
}
