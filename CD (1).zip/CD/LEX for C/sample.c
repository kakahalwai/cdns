int main() {
    int x = 10;
    float y = 3.14;
    string c = "Hello";
    if (x < y) {
        x = x + 1;
    } else {
        x = x - 1;
    }
}
