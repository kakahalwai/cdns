#include <iostream>
#include <vector>
#include <tuple>

using namespace std;

string convert_to_three_address_code(const vector<tuple<char, string, string, string>>& quadruples) {
    string three_address_code = "";
    for (const auto& quad : quadruples) {
        char op;
        string arg1, arg2, result;
        tie(op, arg1, arg2, result) = quad;

        string code_line = result + " = ";
        if (op != '=') {
            code_line += arg1 + " " + op + " " + arg2;
        } else {
            code_line += arg1;
        }

        three_address_code += code_line + "\n";
    }
    return three_address_code;
}

int main() {
    // Example input: List of quadruples
    vector<tuple<char, string, string, string>> optimized_quadruples = {
        {'+', "x", "y", "t1"},
        {'*', "t1", "z", "t2"},
        {'=', "t2", "", "a"},
        {'+', "x", "y", "t3"},
        {'*', "t3", "z", "t4"},
        {'=', "t4", "", "b"}
    };

    string three_address_code = convert_to_three_address_code(optimized_quadruples);

    // Printing 3-address code
    cout << "3-address code:" << endl;
    cout << three_address_code;

    return 0;
}
